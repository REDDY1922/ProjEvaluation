package com.springboot.main.library.enums;

public enum RoleType {
    Admin,CUSTOMER
}
