import AdminNavbar from "./adminnavbar";


function DeleteComponent(){
  
   

    return(
        <div>
            <AdminNavbar />
            <h1>Deleted Successfully</h1>
            
    </div>

       
    )
}
export default DeleteComponent;