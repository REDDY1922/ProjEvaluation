/* eslint-disable no-unused-vars */

import React, { useState } from "react";
import { Col, Button, Row, Container, Card, Form } from "react-bootstrap";
import { useNavigate, useSearchParams } from "react-router-dom";
import axios from "axios";
import './login.css';


function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [msg, setMsg] = useState('');
  const navigate = useNavigate();
  const [param]=useSearchParams();
  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const doLogin = (e) => {
    e.preventDefault();
    let token = window.btoa(username + ':' + password);
    console.log('Request Headers:', {
      'Authorization': 'Basic ' + token
    })
    
    axios.post('http://localhost:8182/auth/login', {}, {
       headers: {
         'Authorization': 'Basic ' + token
      }
    })
      .then(function (response) {
        localStorage.setItem('username', username);
        localStorage.setItem('token', token);
        localStorage.setItem('id', response.data.id);
        localStorage.setItem('isLoggedIn', true);
        let role = response.data.user.role;
        switch (role) {
          case 'Admin':
            navigate('/admin/dashboard/'+response.data.id)
            break;
          case 'CUSTOMER':
            navigate('/customer/dashboard/'+response.data.id)
            break;
          default:
        }
      })
      .catch(function (error) {
        setMsg('Invalid Credintials')
      })
  }

  return (
    <div style={{ 
      backgroundImage:  'url("https://th.bing.com/th?id=OSK.HEROocjiR_aWsPqAy8aUEsEhA9rA-6-pQaXH-d4uzWT36IA&w=384&h=228&c=1&rs=2&o=6&pid=SANGAM")', 
      backgroundSize: 'cover', 
      backgroundPosition: 'center', 
      minHeight: "100vh",
      backgroundColor: 'rgba(0, 0, 0, 0.5)' // Adjust the last value (0.5) for the desired transparency
    }}>
      <Container>
        <Row className="vh-100 d-flex justify-content-center align-items-center">
          <Col md={8} lg={6} xs={12}>
            <div className="border border-3 border-primary"></div>
            <Card className="shadow" style={{ backgroundColor: 'rgba(255, 255, 255, 0.7)' }}>
            <Card.Body>
              <div className="mb-3 mt-md-4">
                <h2 className="fw-bold mb-2 text-uppercase">Welcome to INFOLIBRA</h2>
                <p className="mb-5">Please enter your login and password!</p>
                <div className="mb-3">
                  <Form onSubmit={doLogin}>
                    <Form.Group className="mb-3" controlId="formBasicEmail">
                      <Form.Label className="text-center">Username</Form.Label>
                      <Form.Control type="text" placeholder="Enter username" onChange={(e) => setUsername(e.target.value)} />
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicPassword">
                      <Form.Label>Password</Form.Label>
                      <div className="input-group">
                        <Form.Control
                          type={showPassword ? "text" : "password"}
                          placeholder="Password"
                          onChange={(e) => setPassword(e.target.value)}
                        />
                      </div>
                    </Form.Group>

                    <Form.Group className="mb-3" controlId="formBasicCheckbox">
                      <div className="d-flex justify-content-between align-items-center">
                        <div className="checkbox-container">
                          <Form.Check
                            type="checkbox"
                            label="Show Password"
                            onChange={togglePasswordVisibility}
                          />
                        </div>
                        <p className="small checkbox-label">
                          <a className="text-primary" href="#!">
                            Forgot password?
                          </a>
                        </p>
                      </div>
                    </Form.Group>

                    <div className="d-grid">
                      <Button variant="primary" type="submit">
                        Login
                      </Button>
                    </div>
                  </Form>
                  <div className="mt-3">
                    <p className="mb-0 text-center">
                      Donot have an account?{" "}
                      <a href="/auth/signup" className="text-primary fw-bold">
                        Sign Up
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </Card.Body>
          </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
}

export default Login;