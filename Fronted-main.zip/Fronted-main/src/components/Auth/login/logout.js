function Logout(){
    return(
        <div>
            <h3>Logout</h3>
        </div>
    )
}
export default Logout;